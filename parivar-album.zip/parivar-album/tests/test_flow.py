"""End-to-end test of the whole app using the TEST-ONLY mock face engine
(coloured squares act as faces; each colour = one person).

    python tests/test_flow.py

It exercises login, upload, auto-recognition, naming, search, downloads, merge,
re-tagging, permissions and a few security cases. Real-face accuracy must be checked
on your own photos with check_faces.py.
"""
import io
import os
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
TMP = tempfile.mkdtemp(prefix="family-test-")
os.environ.update(DATA_DIR=TMP, FAMILY_PASSWORD="fam-pass", ADMIN_PASSWORD="admin-pass",
                  FACE_ENGINE="mock", SECRET_KEY="test")

import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402

import app as family  # noqa: E402

RED, GREEN, BLUE, ORANGE = (255, 0, 0), (0, 200, 0), (0, 0, 255), (255, 140, 0)  # RGB


def make_photo(colors, jitter=0, size=(800, 600), exif_orientation=None):
    rng = np.random.default_rng(abs(hash((tuple(colors), jitter))) % 2**32)
    img = Image.new("RGB", size, (255, 255, 255))
    for i, c in enumerate(colors):
        c = tuple(int(np.clip(v + rng.integers(-8, 9), 0, 255)) for v in c)
        img.paste(Image.new("RGB", (130, 130), c), (60 + i * 220, 150 + jitter))
    buf = io.BytesIO()
    if exif_orientation:
        ex = Image.Exif()
        ex[0x0112] = exif_orientation
        img.save(buf, "JPEG", exif=ex)
    else:
        img.save(buf, "JPEG")
    return buf.getvalue()


def login(client, pw):
    return client.post("/login", data={"password": pw})


def upload(client, data, name, album=""):
    return client.post("/api/upload", data={"file": (io.BytesIO(data), name), "album": album},
                       content_type="multipart/form-data")


class FamilyFlow(unittest.TestCase):
    def setUp(self):
        self.c = family.app.test_client()

    def test_full_family_flow(self):
        c = self.c
        # --- auth -----------------------------------------------------------
        self.assertEqual(c.get("/").status_code, 302)
        self.assertEqual(c.post("/api/upload").status_code, 401)
        self.assertIn(b"Wrong password", login(c, "nope").data)
        self.assertEqual(login(c, "fam-pass").status_code, 302)
        self.assertEqual(c.get("/").status_code, 200)

        # --- bulk upload + automatic grouping -------------------------------
        p1 = make_photo([RED, GREEN])
        r = upload(c, p1, "party1.jpg", "Aryan's Birthday").get_json()
        self.assertEqual((r["faces"], r["new_people"]), (2, 2))
        r = upload(c, make_photo([RED, BLUE], 5), "party2.jpg", "Aryan's Birthday").get_json()
        self.assertEqual((r["faces"], r["recognised"], r["new_people"]), (2, 1, 1))
        r = upload(c, make_photo([GREEN], 9), "party3.jpg", "Aryan's Birthday").get_json()
        self.assertEqual((r["faces"], r["recognised"], r["new_people"]), (1, 1, 0))
        self.assertEqual(upload(c, p1, "again.jpg").get_json()["status"], "duplicate")
        self.assertEqual(upload(c, b"not an image", "x.jpg").status_code, 400)
        self.assertEqual(upload(c, p1, "evil.exe").status_code, 400)

        # --- name the three groups -----------------------------------------
        with family.app.app_context():
            people = family.all_people()
        by_cnt = {p["id"]: p["cnt"] for p in people}
        self.assertEqual(sorted(by_cnt.values()), [1, 2, 2])
        self.assertIn(b"Who is this?", c.get("/").data)

        with family.app.app_context():
            con = family.db()
            def pid_of(photo_orig_name, left_to_right_index):
                ph = con.execute("SELECT id FROM photos WHERE orig_name=?", (photo_orig_name,)).fetchone()
                fs = con.execute("SELECT person_id FROM faces WHERE photo_id=? ORDER BY x", (ph["id"],)).fetchall()
                return fs[left_to_right_index]["person_id"]
            red, green = pid_of("party1.jpg", 0), pid_of("party1.jpg", 1)
            blue = pid_of("party2.jpg", 1)
        self.assertEqual(len({red, green, blue}), 3)
        for pid, name in ((red, "Aryan"), (green, "Ishansh"), (blue, "Dadi")):
            res = c.post(f"/api/person/{pid}/rename", json={"name": name}).get_json()
            self.assertTrue(res["ok"])

        home = c.get("/")                      # home must render once people have names
        self.assertEqual(home.status_code, 200)
        for name in (b"Aryan", b"Ishansh", b"Dadi"):
            self.assertIn(name, home.data)
        self.assertNotIn(b"Who is this?", home.data)  # nobody left unnamed

        # --- search by name (case-insensitive, partial) ---------------------
        page = c.get("/search?q=aryan").get_data(as_text=True)
        # Aryan's 2 photos + the 3 photos of the album "Aryan's Birthday" (name also matches the album)
        self.assertEqual(page.count('class="tile"'), 5)
        self.assertIn("/person/%d" % red, page)
        self.assertEqual(c.get("/search?q=ISH").get_data(as_text=True).count("/person/%d" % green) >= 1, True)
        self.assertIn("No person or album matches", c.get("/search?q=zzzz").get_data(as_text=True))
        wild = c.get("/search?q=%25").get_data(as_text=True)  # '%' must not match everything
        self.assertIn("No person or album matches", wild)

        # --- profile pages hold the right photos ---------------------------
        def tiles(pid):
            return c.get(f"/person/{pid}").get_data(as_text=True).count('class="tile"')
        self.assertEqual((tiles(red), tiles(green), tiles(blue)), (2, 2, 1))

        # --- new photos of NAMED people are filed automatically -------------
        r = upload(c, make_photo([RED, BLUE], 17), "party4.jpg").get_json()
        self.assertEqual((r["faces"], r["recognised"], r["new_people"]), (2, 2, 0))
        self.assertEqual((tiles(red), tiles(blue)), (3, 2))

        # --- downloads ------------------------------------------------------
        z = c.get(f"/person/{red}/download")
        self.assertEqual(z.mimetype, "application/zip")
        zf = zipfile.ZipFile(io.BytesIO(z.data))
        self.assertEqual(len(zf.namelist()), 3)
        with family.app.app_context():
            ids = [str(r["id"]) for r in family.photos_of_person(green)]
        z2 = zipfile.ZipFile(io.BytesIO(c.post("/download.zip", data={"ids": ",".join(ids)}).data))
        self.assertEqual(len(z2.namelist()), 2)
        with family.app.app_context():
            p1id = family.db().execute("SELECT id FROM photos WHERE orig_name='party1.jpg'").fetchone()["id"]
        dl = c.get(f"/file/orig/{p1id}?dl=1")
        self.assertEqual(dl.data, p1)                       # original bytes untouched
        self.assertIn("attachment", dl.headers["Content-Disposition"])

        # --- fragment + merge: unknown face gets the same name -> merged -----
        upload(c, make_photo([ORANGE]), "uncle.jpg")
        upload(c, make_photo([ORANGE], 30), "uncle2.jpg")
        with family.app.app_context():
            frag = [p for p in family.all_people() if not p["name"]]
        self.assertEqual(len(frag), 1)
        self.assertEqual(frag[0]["cnt"], 2)
        r1 = c.post(f"/api/person/{frag[0]['id']}/rename", json={"name": "Chachu"}).get_json()
        self.assertFalse(r1["merged"])
        upload(c, make_photo([ORANGE], 60), "uncle3.jpg")
        self.assertEqual(tiles(frag[0]["id"]), 3)

        # --- fix a wrong tag from the photo page ----------------------------
        with family.app.app_context():
            con = family.db()
            ph = con.execute("SELECT id FROM photos WHERE orig_name='uncle3.jpg'").fetchone()["id"]
            fid = con.execute("SELECT id FROM faces WHERE photo_id=?", (ph,)).fetchone()["id"]
        self.assertTrue(c.post(f"/api/face/{fid}/assign", json={"new_name": "Mamu"}).get_json()["ok"])
        self.assertIn("Mamu", c.get(f"/photo/{ph}").get_data(as_text=True))
        self.assertTrue(c.post(f"/api/face/{fid}/assign", json={"ignore": True}).get_json()["ok"])
        with family.app.app_context():   # empty unnamed/“Mamu” profile has no photos now
            names = [p["name"] for p in family.all_people()]
        self.assertIn("Mamu", names)

        # --- permissions: members cannot delete ----------------------------
        self.assertEqual(c.post(f"/api/photo/{p1id}/delete").status_code, 403)
        self.assertEqual(c.post(f"/api/person/{blue}/delete").status_code, 403)
        admin = family.app.test_client()
        login(admin, "admin-pass")
        with family.app.app_context():
            row = family.db().execute("SELECT * FROM photos WHERE id=?", (p1id,)).fetchone()
        self.assertTrue(os.path.isfile(os.path.join(TMP, "orig", row["filename"])))
        self.assertTrue(admin.post(f"/api/photo/{p1id}/delete").get_json()["ok"])
        self.assertFalse(os.path.isfile(os.path.join(TMP, "orig", row["filename"])))
        self.assertEqual(c.get(f"/photo/{p1id}").status_code, 404)

        # --- security -------------------------------------------------------
        for bad in ("/file/orig/abc", "/file/../../etc/passwd/1", "/file/secret/1"):
            self.assertIn(c.get(bad).status_code, (404,))
        c.post("/api/person/%d/rename" % green, json={"name": "<script>alert(1)</script>"})
        html = c.get("/search?q=script").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_phone_photo_rotation_is_respected(self):
        c = self.c
        login(c, "fam-pass")
        data = make_photo([BLUE], size=(800, 600), exif_orientation=6)  # phone held sideways
        r = upload(c, data, "sideways.jpg").get_json()
        self.assertTrue(r["ok"], r)
        with family.app.app_context():
            row = family.db().execute("SELECT width,height FROM photos WHERE id=?", (r["photo_id"],)).fetchone()
        self.assertEqual((row["width"], row["height"]), (600, 800))

    def test_parallel_uploads_do_not_split_one_person(self):
        """Regression: the uploader sends 2 photos at once; same face must stay ONE profile."""
        from concurrent.futures import ThreadPoolExecutor
        login(self.c, "fam-pass")
        with family.app.app_context():
            before = len(family.all_people())

        def go(i):
            cl = family.app.test_client()
            login(cl, "fam-pass")
            return upload(cl, make_photo([(255, 0, 255)], 40 + i * 3), f"par{i}.jpg").get_json()

        with ThreadPoolExecutor(4) as ex:
            results = list(ex.map(go, range(8)))
        self.assertTrue(all(r["ok"] for r in results), results)
        with family.app.app_context():
            self.assertEqual(len(family.all_people()), before + 1)

    def test_login_throttle(self):
        c = family.app.test_client()
        for _ in range(8):
            login(c, "bad")
        self.assertIn(b"Too many attempts", login(c, "fam-pass").data)
        family._attempts.clear()

    def test_missing_models_gives_clear_error(self):
        c = self.c
        login(c, "fam-pass")
        old_engine, old_env = family._engine, os.environ.pop("FACE_ENGINE")
        family._engine = None
        try:
            r = upload(c, make_photo([RED], 99), "nomodel.jpg")
            self.assertEqual(r.status_code, 503)
            self.assertIn("setup_models.py", r.get_json()["error"])
        finally:
            os.environ["FACE_ENGINE"] = old_env
            family._engine = old_engine


if __name__ == "__main__":
    unittest.main(verbosity=2)
