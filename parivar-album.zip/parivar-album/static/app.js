/* Shared helpers + person-page / home-page behaviour */
function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2600);
}

async function postJSON(url, body) {
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    if (r.status === 401) { location.href = "/login"; return { ok: false }; }
    return await r.json();
  } catch (e) {
    return { ok: false, error: "Network problem — please try again." };
  }
}

/* name / rename forms (home + person page) */
document.querySelectorAll(".rename-form").forEach((form) => {
  form.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const name = form.elements.name.value.trim();
    if (!name) return;
    const res = await postJSON(`/api/person/${form.dataset.pid}/rename`, { name });
    if (!res.ok) return toast(res.error || "Could not save.");
    if (res.merged) {
      toast(`Merged with the existing “${name}”`);
      setTimeout(() => (location.href = `/person/${res.id}`), 700);
    } else if (location.pathname.startsWith("/person/")) {
      location.reload();
    } else {
      toast("Saved ✓");
      setTimeout(() => location.reload(), 500);
    }
  });
});

document.querySelectorAll(".merge-btn").forEach((btn) => {
  btn.addEventListener("click", async () => {
    if (!confirm("Merge these two profiles? Every photo moves to the person you picked.")) return;
    const res = await postJSON(`/api/person/${btn.dataset.pid}/merge`, { into: Number(btn.dataset.into) });
    if (res.ok) location.href = `/person/${res.id}`;
    else toast(res.error || "Could not merge.");
  });
});

const delPerson = document.getElementById("deletePerson");
if (delPerson) {
  delPerson.addEventListener("click", async () => {
    if (!confirm("Remove this profile? Photos are kept — they just become untagged.")) return;
    const res = await postJSON(`/api/person/${delPerson.dataset.pid}/delete`);
    if (res.ok) location.href = "/";
    else toast(res.error || "Could not remove.");
  });
}

/* multi-select download on a person page */
const grid = document.querySelector(".grid[data-selectable]");
const toggle = document.getElementById("selectToggle");
if (grid && toggle) {
  const selected = new Set();
  const zipForm = document.getElementById("zipForm");
  const refresh = () => {
    document.getElementById("selCount").textContent = selected.size;
    document.getElementById("zipIds").value = [...selected].join(",");
    zipForm.hidden = selected.size === 0;
  };
  toggle.addEventListener("click", () => {
    const on = grid.classList.toggle("selecting");
    toggle.textContent = on ? "Cancel selection" : "Select photos";
    if (!on) { selected.clear(); grid.querySelectorAll(".tile.sel").forEach((t) => t.classList.remove("sel")); refresh(); }
  });
  grid.addEventListener("click", (ev) => {
    if (!grid.classList.contains("selecting")) return;
    const tile = ev.target.closest(".tile");
    if (!tile) return;
    ev.preventDefault();
    const id = tile.dataset.id;
    if (selected.has(id)) { selected.delete(id); tile.classList.remove("sel"); }
    else { selected.add(id); tile.classList.add("sel"); }
    refresh();
  });
}
