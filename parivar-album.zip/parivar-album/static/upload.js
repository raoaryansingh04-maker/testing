/* Bulk uploader: sends photos one by one (2 at a time) with live progress */
(() => {
  const drop = document.getElementById("drop");
  const input = document.getElementById("files");
  const queue = document.getElementById("queue");
  const summary = document.getElementById("summary");
  const done = document.getElementById("done");
  const album = document.getElementById("album");
  const stats = { total: 0, finished: 0, added: 0, dup: 0, failed: 0, faces: 0, newPeople: 0 };

  function addFiles(list) {
    const files = [...list].filter((f) => f.type.startsWith("image/") || /\.(hei[cf])$/i.test(f.name));
    if (!files.length) return toast("Please choose photo files.");
    const albumName = album.value.trim();
    files.forEach((f) => pending.push({ file: f, album: albumName, li: row(f.name) }));
    stats.total += files.length;
    summary.hidden = false;
    paint();
    pump();
  }

  const pending = [];
  let active = 0;

  function row(name) {
    const li = document.createElement("li");
    const n = document.createElement("span");
    n.className = "name"; n.textContent = name;
    const s = document.createElement("span");
    s.textContent = "waiting…";
    li.append(n, s);
    queue.appendChild(li);
    return s;
  }

  function paint() {
    summary.textContent = "";
    const t = document.createElement("div");
    t.textContent = `${stats.finished} of ${stats.total} done` +
      (stats.faces ? ` · ${stats.faces} faces found` : "") +
      (stats.dup ? ` · ${stats.dup} already in album` : "") +
      (stats.failed ? ` · ${stats.failed} failed` : "");
    const bar = document.createElement("div");
    bar.className = "bar";
    const fill = document.createElement("i");
    fill.style.width = (stats.total ? (stats.finished / stats.total) * 100 : 0) + "%";
    bar.appendChild(fill);
    summary.append(t, bar);
    done.hidden = !(stats.total && stats.finished === stats.total);
  }

  async function send(job) {
    job.li.textContent = "uploading…";
    const fd = new FormData();
    fd.append("file", job.file);
    fd.append("album", job.album);
    try {
      const r = await fetch("/api/upload", { method: "POST", body: fd });
      if (r.status === 401) { location.href = "/login"; return; }
      const res = await r.json();
      if (res.ok && res.status === "duplicate") {
        stats.dup++; job.li.textContent = "already uploaded";
      } else if (res.ok) {
        stats.added++; stats.faces += res.faces || 0; stats.newPeople += res.new_people || 0;
        job.li.className = "ok";
        job.li.textContent = res.faces ? `✓ ${res.faces} face${res.faces > 1 ? "s" : ""}` : "✓ no faces found";
      } else {
        stats.failed++; job.li.className = "bad"; job.li.textContent = res.error || "failed";
      }
    } catch (e) {
      stats.failed++; job.li.className = "bad"; job.li.textContent = "network error";
    }
    stats.finished++;
    paint();
  }

  function pump() {
    while (active < 2 && pending.length) {
      const job = pending.shift();
      active++;
      send(job).finally(() => { active--; pump(); });
    }
  }

  input.addEventListener("change", () => { addFiles(input.files); input.value = ""; });
  ["dragenter", "dragover"].forEach((e) => drop.addEventListener(e, (ev) => { ev.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach((e) => drop.addEventListener(e, (ev) => { ev.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", (ev) => addFiles(ev.dataTransfer.files));
})();
