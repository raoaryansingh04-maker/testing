/* Photo page: face boxes, who's-in-this-photo list, and re-tagging popover */
(() => {
  const data = JSON.parse(document.getElementById("photo-data").textContent);
  const boxes = document.getElementById("boxes");
  const who = document.getElementById("who");
  const pop = document.getElementById("pop");
  const chips = document.getElementById("chips");
  let current = null;

  function render() {
    boxes.textContent = "";
    who.textContent = "";
    const seen = new Set();
    data.faces.forEach((f) => {
      if (f.ignored) return;
      const b = document.createElement("button");
      b.type = "button";
      b.className = "facebox" + (f.person_id ? "" : " unknown");
      b.style.cssText = `left:${f.x * 100}%;top:${f.y * 100}%;width:${f.w * 100}%;height:${f.h * 100}%`;
      b.setAttribute("aria-label", f.label || "Unknown face — tap to name");
      const s = document.createElement("span");
      s.textContent = f.label || "Who?";
      b.appendChild(s);
      b.addEventListener("click", (ev) => { ev.stopPropagation(); openPop(f, b); });
      boxes.appendChild(b);
      if (f.person_id && !seen.has(f.person_id)) {
        seen.add(f.person_id);
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = `/person/${f.person_id}`;
        a.textContent = f.label;
        li.appendChild(a);
        who.appendChild(li);
      }
    });
    if (!who.children.length) {
      const li = document.createElement("li");
      li.className = "muted";
      li.textContent = data.faces.some((f) => !f.ignored) ? "Nobody named yet" : "No faces found";
      who.appendChild(li);
    }
  }

  function openPop(face, el) {
    current = face;
    document.querySelectorAll(".facebox.active").forEach((n) => n.classList.remove("active"));
    el.classList.add("active");
    chips.textContent = "";
    data.people.forEach((p) => {
      const c = document.createElement("button");
      c.type = "button";
      c.className = "chip" + (p.id === face.person_id ? " on" : "");
      c.textContent = p.name;
      c.addEventListener("click", () => assign({ person_id: p.id }));
      chips.appendChild(c);
    });
    pop.hidden = false;
    const r = el.getBoundingClientRect();
    const pw = pop.offsetWidth, ph = pop.offsetHeight;
    let left = Math.min(Math.max(r.left, 8), window.innerWidth - pw - 8);
    let top = r.bottom + 30;
    if (top + ph > window.innerHeight - 8) top = Math.max(8, r.top - ph - 8);
    pop.style.left = left + "px";
    pop.style.top = top + "px";
  }

  function closePop() {
    pop.hidden = true;
    current = null;
    document.querySelectorAll(".facebox.active").forEach((n) => n.classList.remove("active"));
  }

  async function assign(body) {
    if (!current) return;
    const res = await postJSON(`/api/face/${current.id}/assign`, body);
    if (res.ok) location.reload();
    else toast(res.error || "Could not update.");
  }

  document.getElementById("popClose").addEventListener("click", closePop);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePop(); });
  document.addEventListener("click", (e) => { if (!pop.hidden && !pop.contains(e.target)) closePop(); });
  document.getElementById("notFace").addEventListener("click", () => assign({ ignore: true }));
  document.getElementById("newForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("newName").value.trim();
    if (name) assign({ new_name: name });
  });

  const del = document.getElementById("deletePhoto");
  if (del) {
    del.addEventListener("click", async () => {
      if (!confirm("Delete this photo for everyone? This cannot be undone.")) return;
      const res = await postJSON(`/api/photo/${del.dataset.id}/delete`);
      if (res.ok) location.href = "/";
      else toast(res.error || "Could not delete.");
    });
  }
  render();
})();
