"""Face detection + recognition engines.

Real engine  : OpenCV YuNet (detector) + SFace (128-d embeddings). No dlib needed.
Test engine  : FACE_ENGINE=mock  -> fake "faces" (coloured squares) so the rest of
               the app can be tested without model files. Never use in production.
"""
import os
import threading

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE, "models")
YUNET_PATH = os.path.join(MODEL_DIR, "face_detection_yunet_2023mar.onnx")
SFACE_PATH = os.path.join(MODEL_DIR, "face_recognition_sface_2021dec.onnx")


class ModelsMissing(RuntimeError):
    pass


def _unit(v):
    v = v.astype(np.float32).flatten()
    n = float(np.linalg.norm(v))
    return v / n if n > 0 else v


class OpenCVEngine:
    name = "opencv-yunet-sface"

    def __init__(self):
        for path, min_size in ((YUNET_PATH, 100_000), (SFACE_PATH, 1_000_000)):
            if not (os.path.isfile(path) and os.path.getsize(path) > min_size):
                raise ModelsMissing(
                    "Face models not found. Run:  python setup_models.py"
                )
        self._lock = threading.Lock()  # OpenCV DNN objects are not thread-safe
        self._det = cv2.FaceDetectorYN.create(YUNET_PATH, "", (320, 320), 0.7, 0.3, 5000)
        self._rec = cv2.FaceRecognizerSF.create(SFACE_PATH, "")

    def analyze(self, bgr):
        """Return a list of dicts: x,y,w,h (0-1 relative), score, px (face width in px), emb."""
        h, w = bgr.shape[:2]
        out = []
        with self._lock:
            self._det.setInputSize((w, h))
            _, found = self._det.detect(bgr)
            if found is None:
                return out
            for row in found:
                aligned = self._rec.alignCrop(bgr, row)
                emb = _unit(self._rec.feature(aligned))
                x, y, fw, fh = [float(v) for v in row[:4]]
                x0, y0 = max(x, 0.0), max(y, 0.0)
                x1, y1 = min(x + fw, w), min(y + fh, h)
                if x1 <= x0 or y1 <= y0:
                    continue
                out.append({
                    "x": x0 / w, "y": y0 / h, "w": (x1 - x0) / w, "h": (y1 - y0) / h,
                    "score": float(row[14]), "px": x1 - x0, "emb": emb,
                })
        return out


class MockEngine:
    """Treats every non-white square blob as a 'face'; identity = its colour."""
    name = "mock (TEST ONLY)"

    def analyze(self, bgr):
        h, w = bgr.shape[:2]
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        _, mask = cv2.threshold(gray, 235, 255, cv2.THRESH_BINARY_INV)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out = []
        for c in cnts:
            x, y, bw, bh = cv2.boundingRect(c)
            if bw < 30 or bh < 30:
                continue
            crop = bgr[y:y + bh, x:x + bw]
            mean = crop.reshape(-1, 3).mean(axis=0)
            b, g, r = (min(int(v // 85), 2) for v in mean)  # 27 colour bins = 27 "identities"
            emb = np.full(128, 0.01, np.float32)
            emb[r * 9 + g * 3 + b] = 1.0
            out.append({"x": x / w, "y": y / h, "w": bw / w, "h": bh / h,
                        "score": 0.99, "px": float(bw), "emb": _unit(emb)})
        out.sort(key=lambda f: f["x"])
        return out


def load_engine():
    if os.environ.get("FACE_ENGINE", "").lower() == "mock":
        return MockEngine()
    return OpenCVEngine()
