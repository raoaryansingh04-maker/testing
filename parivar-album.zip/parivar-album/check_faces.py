"""Quick accuracy check on your own photos.

    python check_faces.py a.jpg b.jpg [c.jpg ...]

Prints every face found and the similarity between all faces. Same person is
usually >= 0.45, different people are usually < 0.30. Use it to tune
MATCH_THRESHOLD in .env (siblings look alike, so go a bit higher for them).
"""
import sys

import cv2
import numpy as np

from faces import load_engine


def main(paths):
    engine = load_engine()
    faces = []
    for p in paths:
        img = cv2.imread(p)
        if img is None:
            print(f"{p}: cannot read image")
            continue
        found = engine.analyze(img)
        print(f"{p}: {len(found)} face(s)")
        for i, f in enumerate(found):
            print(f"   face {i}: score={f['score']:.2f} width={f['px']:.0f}px")
            faces.append((f"{p}#{i}", f["emb"]))
    print("\nSimilarity (cosine):")
    for i in range(len(faces)):
        for j in range(i + 1, len(faces)):
            sim = float(np.dot(faces[i][1], faces[j][1]))
            print(f"   {faces[i][0]}  vs  {faces[j][0]}:  {sim:.2f}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    main(sys.argv[1:])
