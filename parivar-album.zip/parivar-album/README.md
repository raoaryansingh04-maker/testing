# Parivar Album — private family photo gallery with automatic face sorting

Upload a whole function's photos at once. Faces are detected and recognised, and each
photo lands in the profile of every person in it. Search a name, see all their photos,
download one or all.

* **Auto-tagging** — OpenCV YuNet (detection) + SFace (128-d face embeddings). No dlib / no cloud API; all data stays on your server.
* **Self-organising** — unknown faces are grouped into "Unnamed" profiles; type a name once and every past and future photo of that person is filed under it. Same name twice = merged.
* **Fix mistakes** — tap a face box on any photo to re-assign it, create a new person, or mark "not a face".
* **Search** by person or event/album name (`Aryan` → all of Aryan's photos).
* **Download** originals untouched: single photo, a person's entire set, or a hand-picked selection as a ZIP.
* Bulk uploader with progress, duplicate detection, phone-rotation (EXIF) handling, optional event/album label.
* Password-protected (family password + optional admin password for deleting).

Stack: Python, Flask, SQLite, OpenCV, Pillow, vanilla JS.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python setup_models.py                                # downloads ~39 MB of face models (checksum-verified)
cp .env.example .env                                  # then edit passwords
python app.py                                         # http://localhost:8000
```

Check recognition quality on your own photos (and tune `MATCH_THRESHOLD`):

```bash
python check_faces.py aryan1.jpg aryan2.jpg ishansh.jpg
```

Run the tests (uses a fake face engine, no models needed): `python tests/test_flow.py`

## Put it on the internet

Photos need **persistent disk** — free hosts that wipe their disk on restart (e.g. Render/Heroku free tiers) will lose them.

* **Easiest + free:** run on a home PC/laptop/Raspberry Pi and publish it with a [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/) (no port-forwarding). Set `TRUST_PROXY=1` and `COOKIE_SECURE=1`.
* **Cloud:** any small VPS (1 GB RAM is enough). Run `pip install gunicorn` then
  `gunicorn -w 1 --threads 4 -b 0.0.0.0:8000 app:app` behind HTTPS (Caddy/nginx). Back up the `data/` folder.

## Privacy

Face embeddings are biometric data of your relatives. Use a strong password, keep HTTPS on,
don't expose the site without the login, and back up `data/` (it holds photos + `family.db`).

## Config (`.env`)

| Variable | Meaning |
|---|---|
| `FAMILY_PASSWORD` | required; shared password for everyone |
| `ADMIN_PASSWORD` | optional; if set, only admin can delete photos/profiles |
| `MATCH_THRESHOLD` | face similarity needed to match (default `0.42`; raise if siblings get mixed up, lower if one person splits in two) |
| `DATA_DIR` | where photos and database live (default `./data`) |
| `TRUST_PROXY`, `COOKIE_SECURE` | set to `1` behind a proxy/HTTPS |

## Known limits

* Babies growing up, heavy side-profiles, masks/sunglasses and very small faces in big group shots are the hard cases — fix them by tapping the face box; corrections improve later matching.
* Twins / very similar siblings may need a higher `MATCH_THRESHOLD` and a few manual fixes.
* HEIC files from iPhones: browsers usually convert to JPEG on upload; otherwise `pip install pillow-heif`.

## Ideas to extend

Birthday/age timeline per person, shared "favourites", per-person accounts, S3/Backblaze storage, face-crop based "this is X?" confirmation queue.
