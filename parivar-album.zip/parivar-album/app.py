"""Family Photos - private photo gallery with automatic face-based sorting."""
import hashlib
import hmac
import io
import os
import secrets
import sqlite3
import tempfile
import threading
import time
import uuid
import zipfile
from datetime import datetime

import cv2
import numpy as np
from flask import (Flask, Response, abort, g, jsonify, redirect, render_template,
                   request, send_file, session, url_for)
from PIL import Image, ImageOps

import faces as face_engine

BASE = os.path.dirname(os.path.abspath(__file__))


def _load_dotenv(path):
    if not os.path.isfile(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_dotenv(os.path.join(BASE, ".env"))

DATA_DIR = os.environ.get("DATA_DIR", os.path.join(BASE, "data"))
DB_PATH = os.path.join(DATA_DIR, "family.db")
DIRS = {k: os.path.join(DATA_DIR, k) for k in ("orig", "web", "thumb", "facecrop")}
for d in DIRS.values():
    os.makedirs(d, exist_ok=True)

FAMILY_PASSWORD = os.environ.get("FAMILY_PASSWORD", "")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
MATCH_THRESHOLD = float(os.environ.get("MATCH_THRESHOLD", "0.42"))
NEW_PERSON_MIN_SCORE = 0.85   # only confident, clear faces may start a new person
NEW_PERSON_MIN_PX = 48
ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".heic", ".heif"}

try:  # optional: iPhone HEIC support
    import pillow_heif
    pillow_heif.register_heif_opener()
except Exception:  # noqa: BLE001
    pass
Image.MAX_IMAGE_PIXELS = 120_000_000

app = Flask(__name__)
app.config.update(
    MAX_CONTENT_LENGTH=80 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 60,
)
if os.environ.get("TRUST_PROXY") == "1":  # behind Cloudflare Tunnel / nginx
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)


def _secret_key():
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    path = os.path.join(DATA_DIR, "secret_key")
    if not os.path.isfile(path):
        with open(path, "w") as fh:
            fh.write(secrets.token_hex(32))
        os.chmod(path, 0o600)
    with open(path) as fh:
        return fh.read().strip()


app.secret_key = _secret_key()

# --------------------------------------------------------------------------- db
SCHEMA = """
CREATE TABLE IF NOT EXISTS photos(
  id INTEGER PRIMARY KEY, filename TEXT NOT NULL, orig_name TEXT, sha256 TEXT UNIQUE,
  width INTEGER, height INTEGER, taken_at TEXT, uploaded_at TEXT NOT NULL,
  album TEXT, uploader TEXT);
CREATE TABLE IF NOT EXISTS people(
  id INTEGER PRIMARY KEY, name TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS faces(
  id INTEGER PRIMARY KEY,
  photo_id INTEGER NOT NULL REFERENCES photos(id) ON DELETE CASCADE,
  person_id INTEGER REFERENCES people(id) ON DELETE SET NULL,
  x REAL, y REAL, w REAL, h REAL, score REAL, embedding BLOB,
  confirmed INTEGER DEFAULT 0, ignored INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_faces_person ON faces(person_id);
CREATE INDEX IF NOT EXISTS idx_faces_photo ON faces(photo_id);
"""


def init_db():
    con = sqlite3.connect(DB_PATH)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    con.commit()
    con.close()


init_db()


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=30)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


@app.teardown_appcontext
def _close_db(_exc):
    con = g.pop("db", None)
    if con is not None:
        con.close()


_engine = None


def get_engine():
    global _engine
    if _engine is None:
        _engine = face_engine.load_engine()
    return _engine


# ------------------------------------------------------------------------- auth
_attempts = {}


def _throttled(ip):
    now = time.time()
    n, first = _attempts.get(ip, (0, now))
    if now - first > 600:
        n, first = 0, now
    _attempts[ip] = (n, first)
    return n >= 8


def _fail(ip):
    n, first = _attempts.get(ip, (0, time.time()))
    _attempts[ip] = (n + 1, first)


@app.before_request
def require_login():
    if request.endpoint in ("login", "static"):
        return None
    if not FAMILY_PASSWORD:
        return Response("Set FAMILY_PASSWORD in .env before starting the site (see README).", 500)
    if session.get("role"):
        return None
    if request.path.startswith("/api/"):
        return jsonify(ok=False, error="Please log in again."), 401
    return redirect(url_for("login", next=request.path))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        ip = request.remote_addr or "?"
        pw = request.form.get("password", "")
        if _throttled(ip):
            error = "Too many attempts. Try again in a few minutes."
        elif ADMIN_PASSWORD and hmac.compare_digest(pw, ADMIN_PASSWORD):
            session.clear(); session.permanent = True; session["role"] = "admin"
            return redirect(_safe_next())
        elif FAMILY_PASSWORD and hmac.compare_digest(pw, FAMILY_PASSWORD):
            session.clear(); session.permanent = True; session["role"] = "member"
            return redirect(_safe_next())
        else:
            _fail(ip)
            error = "Wrong password."
    return render_template("login.html", error=error)


def _safe_next():
    nxt = request.args.get("next", "/")
    return nxt if nxt.startswith("/") and not nxt.startswith("//") else "/"


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def can_delete():
    return (not ADMIN_PASSWORD) or session.get("role") == "admin"


@app.context_processor
def _ctx():
    return {"can_delete": can_delete(), "pname": pname, "engine_name": _engine.name if _engine else ""}


def pname(p):
    return p["name"] if p["name"] else f"Unnamed #{p['id']}"


# ------------------------------------------------------------------ face logic
def _match_people(con, found):
    """Greedy one-person-per-face assignment. Returns {face_index: person_id}."""
    rows = con.execute(
        "SELECT person_id, embedding FROM faces "
        "WHERE person_id IS NOT NULL AND ignored=0 AND embedding IS NOT NULL").fetchall()
    per = {}
    for r in rows:
        per.setdefault(r["person_id"], []).append(np.frombuffer(r["embedding"], dtype=np.float32))
    mats = {pid: np.stack(v) for pid, v in per.items()}
    scored = []
    for fi, f in enumerate(found):
        for pid, mat in mats.items():
            sims = np.sort(mat @ f["emb"])[-3:]
            scored.append((float(sims.mean()), fi, pid))
    scored.sort(reverse=True)
    assigned, used = {}, set()
    for s, fi, pid in scored:
        if s < MATCH_THRESHOLD:
            break
        if fi in assigned or pid in used:
            continue
        assigned[fi] = pid
        used.add(pid)
    return assigned


def _cleanup_people(con):
    con.execute("DELETE FROM people WHERE name IS NULL AND id NOT IN "
                "(SELECT person_id FROM faces WHERE person_id IS NOT NULL AND ignored=0)")


def _taken_at(img):
    try:
        ex = img.getexif()
        s = ex.get_ifd(0x8769).get(36867) or ex.get(306)
        return datetime.strptime(str(s), "%Y:%m:%d %H:%M:%S").isoformat() if s else None
    except Exception:  # noqa: BLE001
        return None


_process_lock = threading.Lock()


def process_image(data, orig_name, album, uploader):
    # One photo at a time: matching faces and creating new people must be atomic,
    # otherwise two parallel uploads of the same person each create a new profile.
    with _process_lock:
        return _process_image(data, orig_name, album, uploader)


def _process_image(data, orig_name, album, uploader):
    ext = os.path.splitext(orig_name or "")[1].lower()
    if ext not in ALLOWED_EXT:
        return {"ok": False, "error": "Not a supported photo type."}
    digest = hashlib.sha256(data).hexdigest()
    con = db()
    con.execute("BEGIN IMMEDIATE")  # also protects against several worker processes
    dup = con.execute("SELECT id FROM photos WHERE sha256=?", (digest,)).fetchone()
    if dup:
        return {"ok": True, "status": "duplicate", "photo_id": dup["id"]}
    try:
        img = Image.open(io.BytesIO(data))
        taken = _taken_at(img)
        img = ImageOps.exif_transpose(img).convert("RGB")
    except Exception:  # noqa: BLE001
        return {"ok": False, "error": "Could not read this image."}

    engine = get_engine()  # may raise ModelsMissing
    web = img.copy()
    web.thumbnail((2000, 2000))
    bgr = cv2.cvtColor(np.asarray(web), cv2.COLOR_RGB2BGR)
    found = engine.analyze(bgr)
    assigned = _match_people(con, found)

    stem = uuid.uuid4().hex
    fname = stem + (ext if ext in (".jpg", ".jpeg", ".png", ".webp") else ".jpg")
    thumb = web.copy()
    thumb.thumbnail((520, 520))
    web.save(os.path.join(DIRS["web"], stem + ".jpg"), "JPEG", quality=86)
    thumb.save(os.path.join(DIRS["thumb"], stem + ".jpg"), "JPEG", quality=80)
    with open(os.path.join(DIRS["orig"], fname), "wb") as fh:
        fh.write(data)

    now = datetime.now().isoformat(timespec="seconds")
    cur = con.execute(
        "INSERT INTO photos(filename,orig_name,sha256,width,height,taken_at,uploaded_at,album,uploader)"
        " VALUES(?,?,?,?,?,?,?,?,?)",
        (fname, os.path.basename(orig_name or "photo" + ext), digest, img.width, img.height,
         taken, now, (album or "").strip()[:80] or None, uploader))
    photo_id = cur.lastrowid
    new_people = 0
    for fi, f in enumerate(found):
        pid = assigned.get(fi)
        if pid is None and f["score"] >= NEW_PERSON_MIN_SCORE and f["px"] * (web.width / bgr.shape[1]) >= NEW_PERSON_MIN_PX:
            pid = con.execute("INSERT INTO people(name,created_at) VALUES(NULL,?)", (now,)).lastrowid
            new_people += 1
        con.execute(
            "INSERT INTO faces(photo_id,person_id,x,y,w,h,score,embedding) VALUES(?,?,?,?,?,?,?,?)",
            (photo_id, pid, f["x"], f["y"], f["w"], f["h"], f["score"],
             f["emb"].astype(np.float32).tobytes()))
    con.commit()
    return {"ok": True, "status": "added", "photo_id": photo_id, "faces": len(found),
            "recognised": len(assigned), "new_people": new_people}


# ------------------------------------------------------------------ queries
ORDER = "COALESCE(ph.taken_at, ph.uploaded_at) DESC, ph.id DESC"


def all_people():
    return db().execute(f"""
        SELECT p.id, p.name,
          (SELECT COUNT(DISTINCT f.photo_id) FROM faces f WHERE f.person_id=p.id AND f.ignored=0) AS cnt,
          (SELECT f.id FROM faces f WHERE f.person_id=p.id AND f.ignored=0
             ORDER BY f.confirmed DESC, f.score*f.w*f.h DESC LIMIT 1) AS cover
        FROM people p ORDER BY (p.name IS NULL), LOWER(p.name), p.id""").fetchall()


def photos_of_person(pid):
    return db().execute(f"""
        SELECT DISTINCT ph.* FROM photos ph JOIN faces f ON f.photo_id=ph.id
        WHERE f.person_id=? AND f.ignored=0 ORDER BY {ORDER}""", (pid,)).fetchall()


def photo_stem(row):
    return os.path.splitext(row["filename"])[0]


@app.template_filter("stem")
def _stem(row):
    return photo_stem(row)


# ---------------------------------------------------------------------- pages
@app.route("/")
def home():
    people = all_people()
    recent = db().execute(f"SELECT ph.* FROM photos ph ORDER BY ph.uploaded_at DESC, ph.id DESC LIMIT 12").fetchall()
    total = db().execute("SELECT COUNT(*) c FROM photos").fetchone()["c"]
    return render_template("home.html", named=[p for p in people if p["name"]],
                           unnamed=[p for p in people if not p["name"] and p["cnt"]],
                           recent=recent, total=total)


@app.route("/upload")
def upload_page():
    albums = [r["album"] for r in db().execute(
        "SELECT DISTINCT album FROM photos WHERE album IS NOT NULL ORDER BY album").fetchall()]
    return render_template("upload.html", albums=albums)


@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        return redirect(url_for("home"))
    like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    people = db().execute(
        "SELECT id, name FROM people WHERE name LIKE ? ESCAPE '\\' ORDER BY LOWER(name)", (like,)).fetchall()
    groups = [(p, photos_of_person(p["id"])) for p in people]
    albums = db().execute(f"""
        SELECT DISTINCT album FROM photos WHERE album LIKE ? ESCAPE '\\' ORDER BY album""", (like,)).fetchall()
    album_groups = [(a["album"], db().execute(
        f"SELECT ph.* FROM photos ph WHERE ph.album=? ORDER BY {ORDER}", (a["album"],)).fetchall())
        for a in albums]
    return render_template("search.html", q=q, groups=groups, album_groups=album_groups)


@app.route("/person/<int:pid>")
def person_page(pid):
    p = db().execute("SELECT * FROM people WHERE id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    cover = db().execute(
        "SELECT id FROM faces WHERE person_id=? AND ignored=0 ORDER BY confirmed DESC, score*w*h DESC LIMIT 1",
        (pid,)).fetchone()
    others = [o for o in all_people() if o["id"] != pid]
    return render_template("person.html", p=p, photos=photos_of_person(pid),
                           cover=cover["id"] if cover else None, others=others)


@app.route("/photo/<int:photo_id>")
def photo_page(photo_id):
    ph = db().execute("SELECT * FROM photos WHERE id=?", (photo_id,)).fetchone()
    if not ph:
        abort(404)
    fcs = db().execute(
        "SELECT f.id,f.x,f.y,f.w,f.h,f.person_id,f.ignored,p.name FROM faces f "
        "LEFT JOIN people p ON p.id=f.person_id WHERE f.photo_id=? ORDER BY f.x", (photo_id,)).fetchall()
    people = [{"id": p["id"], "name": pname(p)} for p in all_people()]
    face_list = [{"id": f["id"], "x": f["x"], "y": f["y"], "w": f["w"], "h": f["h"],
                  "person_id": f["person_id"], "ignored": bool(f["ignored"]),
                  "label": (f["name"] or ("Unnamed #%d" % f["person_id"])) if f["person_id"] else ""}
                 for f in fcs]
    return render_template("photo.html", ph=ph, faces=face_list, people=people)


# ----------------------------------------------------------------------- files
def _serve(kind, row, download=False):
    stem = photo_stem(row)
    if kind == "orig":
        path = os.path.join(DIRS["orig"], row["filename"])
    elif kind == "web":
        path = os.path.join(DIRS["web"], stem + ".jpg")
    elif kind == "thumb":
        path = os.path.join(DIRS["thumb"], stem + ".jpg")
    else:
        abort(404)
    if not os.path.isfile(path):
        abort(404)
    resp = send_file(path, as_attachment=download, download_name=row["orig_name"] if download else None,
                     max_age=0 if download else 86400 * 30)
    return resp


@app.route("/file/<kind>/<int:photo_id>")
def file_route(kind, photo_id):
    row = db().execute("SELECT * FROM photos WHERE id=?", (photo_id,)).fetchone()
    if not row:
        abort(404)
    return _serve(kind, row, download=request.args.get("dl") == "1")


@app.route("/face/<int:face_id>.jpg")
def face_crop(face_id):
    cache = os.path.join(DIRS["facecrop"], f"{face_id}.jpg")
    if not os.path.isfile(cache):
        r = db().execute("SELECT f.*, ph.filename FROM faces f JOIN photos ph ON ph.id=f.photo_id WHERE f.id=?",
                         (face_id,)).fetchone()
        if not r:
            abort(404)
        img = Image.open(os.path.join(DIRS["web"], os.path.splitext(r["filename"])[0] + ".jpg"))
        W, H = img.size
        cx, cy = (r["x"] + r["w"] / 2) * W, (r["y"] + r["h"] / 2) * H
        half = max(r["w"] * W, r["h"] * H) * 0.75
        box = (max(cx - half, 0), max(cy - half, 0), min(cx + half, W), min(cy + half, H))
        crop = img.crop(tuple(int(v) for v in box))
        crop.thumbnail((220, 220))
        crop.save(cache, "JPEG", quality=85)
    return send_file(cache, max_age=86400 * 30)


def _zip_response(rows, label):
    tmp = tempfile.SpooledTemporaryFile(max_size=64 * 1024 * 1024)
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as zf:
        for r in rows:
            path = os.path.join(DIRS["orig"], r["filename"])
            if os.path.isfile(path):
                zf.write(path, f"{r['id']}_{os.path.basename(r['orig_name'] or r['filename'])}")
    tmp.seek(0)
    safe = "".join(c for c in label if c not in '\\/:*?"<>|').strip() or "photos"
    return send_file(tmp, mimetype="application/zip", as_attachment=True, download_name=f"{safe}.zip")


@app.route("/person/<int:pid>/download")
def person_download(pid):
    p = db().execute("SELECT * FROM people WHERE id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    return _zip_response(photos_of_person(pid), f"{pname(p)} - photos")


@app.route("/download.zip", methods=["POST"])
def selected_download():
    ids = [int(i) for i in request.form.get("ids", "").split(",") if i.strip().isdigit()][:500]
    if not ids:
        abort(400)
    marks = ",".join("?" * len(ids))
    rows = db().execute(f"SELECT * FROM photos WHERE id IN ({marks})", ids).fetchall()
    return _zip_response(rows, "family-photos")


# ------------------------------------------------------------------------ api
@app.route("/api/upload", methods=["POST"])
def api_upload():
    f = request.files.get("file")
    if not f:
        return jsonify(ok=False, error="No file."), 400
    try:
        res = process_image(f.read(), f.filename, request.form.get("album", ""), session.get("role"))
    except face_engine.ModelsMissing as exc:
        return jsonify(ok=False, error=str(exc)), 503
    return jsonify(res), (200 if res.get("ok") else 400)


@app.route("/api/person/<int:pid>/rename", methods=["POST"])
def api_rename(pid):
    name = " ".join((request.get_json(silent=True) or {}).get("name", "").split())[:60]
    if not name:
        return jsonify(ok=False, error="Please type a name."), 400
    con = db()
    if not con.execute("SELECT 1 FROM people WHERE id=?", (pid,)).fetchone():
        abort(404)
    same = con.execute("SELECT id FROM people WHERE LOWER(name)=LOWER(?) AND id<>?", (name, pid)).fetchone()
    if same:  # same name as someone else = same person -> merge
        con.execute("UPDATE faces SET person_id=? WHERE person_id=?", (same["id"], pid))
        con.execute("DELETE FROM people WHERE id=?", (pid,))
        con.commit()
        return jsonify(ok=True, merged=True, id=same["id"])
    con.execute("UPDATE people SET name=? WHERE id=?", (name, pid))
    con.execute("UPDATE faces SET confirmed=1 WHERE person_id=?", (pid,))
    con.commit()
    return jsonify(ok=True, merged=False, id=pid)


@app.route("/api/person/<int:pid>/merge", methods=["POST"])
def api_merge(pid):
    target = (request.get_json(silent=True) or {}).get("into")
    con = db()
    if not isinstance(target, int) or target == pid or \
            not con.execute("SELECT 1 FROM people WHERE id=?", (target,)).fetchone():
        return jsonify(ok=False, error="Pick another person."), 400
    con.execute("UPDATE faces SET person_id=? WHERE person_id=?", (target, pid))
    con.execute("DELETE FROM people WHERE id=?", (pid,))
    con.commit()
    return jsonify(ok=True, id=target)


@app.route("/api/person/<int:pid>/delete", methods=["POST"])
def api_delete_person(pid):
    if not can_delete():
        return jsonify(ok=False, error="Only the admin can do this."), 403
    con = db()
    con.execute("UPDATE faces SET person_id=NULL WHERE person_id=?", (pid,))
    con.execute("DELETE FROM people WHERE id=?", (pid,))
    con.commit()
    return jsonify(ok=True)


@app.route("/api/face/<int:fid>/assign", methods=["POST"])
def api_assign(fid):
    body = request.get_json(silent=True) or {}
    con = db()
    face = con.execute("SELECT * FROM faces WHERE id=?", (fid,)).fetchone()
    if not face:
        abort(404)
    if body.get("ignore"):
        con.execute("UPDATE faces SET person_id=NULL, ignored=1 WHERE id=?", (fid,))
    else:
        pid = body.get("person_id")
        new_name = " ".join(str(body.get("new_name", "")).split())[:60]
        if new_name:
            row = con.execute("SELECT id FROM people WHERE LOWER(name)=LOWER(?)", (new_name,)).fetchone()
            pid = row["id"] if row else con.execute(
                "INSERT INTO people(name,created_at) VALUES(?,?)",
                (new_name, datetime.now().isoformat(timespec="seconds"))).lastrowid
        if not isinstance(pid, int) or not con.execute("SELECT 1 FROM people WHERE id=?", (pid,)).fetchone():
            return jsonify(ok=False, error="Choose a person."), 400
        # a person appears once per photo: free the slot if someone else already holds it
        con.execute("UPDATE faces SET person_id=NULL WHERE photo_id=? AND person_id=? AND id<>?",
                    (face["photo_id"], pid, fid))
        con.execute("UPDATE faces SET person_id=?, ignored=0, confirmed=1 WHERE id=?", (pid, fid))
    _cleanup_people(con)
    con.commit()
    return jsonify(ok=True)


@app.route("/api/photo/<int:photo_id>/delete", methods=["POST"])
def api_delete_photo(photo_id):
    if not can_delete():
        return jsonify(ok=False, error="Only the admin can delete photos."), 403
    con = db()
    row = con.execute("SELECT * FROM photos WHERE id=?", (photo_id,)).fetchone()
    if not row:
        abort(404)
    stem = photo_stem(row)
    for fid in [r["id"] for r in con.execute("SELECT id FROM faces WHERE photo_id=?", (photo_id,))]:
        _rm(os.path.join(DIRS["facecrop"], f"{fid}.jpg"))
    con.execute("DELETE FROM photos WHERE id=?", (photo_id,))
    _cleanup_people(con)
    con.commit()
    _rm(os.path.join(DIRS["orig"], row["filename"]))
    _rm(os.path.join(DIRS["web"], stem + ".jpg"))
    _rm(os.path.join(DIRS["thumb"], stem + ".jpg"))
    return jsonify(ok=True)


def _rm(path):
    try:
        os.remove(path)
    except OSError:
        pass


@app.errorhandler(413)
def _too_big(_e):
    return jsonify(ok=False, error="File too large (limit 80 MB)."), 413


if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "0.0.0.0"), port=int(os.environ.get("PORT", "8000")),
            threaded=True)
