"""Download the two face models (about 39 MB) and verify their SHA-256.

    python setup_models.py

Source: https://github.com/opencv/opencv_zoo  (Apache-2.0 / MIT licensed models)
"""
import hashlib
import os
import sys
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE, "models")
RAW = "https://github.com/opencv/opencv_zoo/raw/main/models/"

MODELS = [
    ("face_detection_yunet_2023mar.onnx", "face_detection_yunet/",
     "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4", 232589),
    ("face_recognition_sface_2021dec.onnx", "face_recognition_sface/",
     "0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79", 38696353),
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    os.makedirs(MODEL_DIR, exist_ok=True)
    ok = True
    for name, folder, digest, size in MODELS:
        dest = os.path.join(MODEL_DIR, name)
        if os.path.isfile(dest) and sha256(dest) == digest:
            print(f"[ok]   {name} already present")
            continue
        url = RAW + folder + name
        print(f"[get]  {url}")
        try:
            urllib.request.urlretrieve(url, dest + ".part")
        except Exception as exc:  # noqa: BLE001
            print(f"[fail] download error: {exc}")
            ok = False
            continue
        if sha256(dest + ".part") != digest:
            print(f"[fail] {name}: checksum mismatch (expected {size} bytes). "
                  "Download it manually from the opencv_zoo repo into models/.")
            os.remove(dest + ".part")
            ok = False
            continue
        os.replace(dest + ".part", dest)
        print(f"[ok]   {name} verified")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
